# HSPT Study Lab

A free, static HSPT study website starter with:
- 50 original practice questions (10 per subject area)
- Section practice and a mixed test
- Answer feedback and explanations
- Local progress saved in your browser
- Built-in tutor responses that work without an API key
- Optional Gemini API chat using a key entered by the user in the browser tab

## Run locally
Open `index.html` in a modern browser.

## Publish free with GitHub Pages
1. Create a new **public** repository on GitHub (ask a parent for help if needed).
2. Upload `index.html` to the top level of the repository.
3. Open repository **Settings → Pages**.
4. Under the build/deployment source, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
5. Wait for the published site link to appear in the Pages section.

GitHub Pages sites are public. Do not put passwords, private information, or API keys in your source code.

## AI tutor
The built-in tutor works without an API key but is a simple rule-based helper, not a generative AI model.
For generative chat, open the website, expand **Connect optional Gemini AI**, and enter your own Gemini API key. The key is held in session storage for that browser tab and is not included in the site files. Requests are sent directly from the browser to Google's Gemini API. Do not share or publish your key. API free-tier availability and rate limits can change; avoid enabling billing if you want to keep the project free. Ask a parent/guardian to help with API account setup.

## Notes
This is an independent learning project. Questions are original examples, not official HSPT questions, and the score is not an official HSPT score estimate.
